# Tableau Dashboard Build Guide

Connect Tableau to `outputs/cleaned_sales.csv` after running the Python script.

## KPI cards
- Total Revenue: `SUM(Revenue)`
- Orders: `COUNTD(InvoiceNo)`
- Units Sold: `SUM(Quantity)`
- Average Order Value: `SUM(Revenue) / COUNTD(InvoiceNo)`
- Unique Customers: `COUNTD(CustomerID)` (missing IDs are ignored by Tableau)

## Recommended sheets
1. **Monthly Revenue** — InvoiceDate as month, `SUM(Revenue)` as line.
2. **Top 10 Countries** — Country vs `SUM(Revenue)`, descending, Top 10 filter.
3. **Top 10 Products** — Description vs `SUM(Revenue)`, descending, Top 10 filter.
4. **Orders by Country** — Country and `COUNTD(InvoiceNo)`.
5. **Sales Detail** — date, country, product, quantity, unit price, revenue.

## Dashboard layout
Place five KPI cards across the top; monthly revenue in the middle; top countries and products at the bottom. Add filters for date, country, and product and apply them to all relevant sheets.

## Validation
Compare Tableau totals against `outputs/kpi_summary.csv`. Note that this dataset is historical (2010–2011), and the dashboard represents analysis of this dataset only.
