Save a screenshot of your finished Tableau dashboard here before publishing your repository.
