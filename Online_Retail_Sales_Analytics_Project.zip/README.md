# Online Retail Sales Analytics (Python + Tableau)

An end-to-end portfolio project using the **UCI Online Retail** dataset to demonstrate data cleaning, exploratory data analysis (EDA), KPI calculation, SQL analysis, and Tableau dashboard preparation.

> **Important:** The original dataset is not included in this repository. Download it from the official UCI page and follow the setup steps below. The data covers transactions from 1 December 2010 to 9 December 2011, so it is historical data—not current business performance.

## Tools
- Python, Pandas, NumPy
- Matplotlib (EDA charts)
- MySQL-compatible SQL queries
- Tableau Public / Tableau Desktop

## Business questions
1. How does monthly revenue change over time?
2. Which countries generate the most revenue?
3. Which products contribute the most revenue?
4. What are order count, units sold, and average order value?
5. How many records are missing customer IDs, duplicated, cancelled, or have invalid quantities/prices?

## Dataset
- Source: UCI Machine Learning Repository — Online Retail
- Official page: https://archive.ics.uci.edu/dataset/352/online-retail
- Citation: Chen, D. (2015). *Online Retail* [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5BW33
- License: CC BY 4.0. Credit the dataset source when publishing your work.

## Setup
1. Install Python 3.10+.
2. Download `Online Retail.xlsx` from the official UCI page.
3. Create a folder named `data/raw/` in this project and put the downloaded file there as `Online Retail.xlsx`.
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. Run:
   ```bash
   python src/analyze_retail.py
   ```
6. Outputs are written to `outputs/`:
   - `cleaned_sales.csv` — cleaned transaction rows for Tableau
   - `monthly_revenue.csv`
   - `country_revenue.csv`
   - `product_revenue.csv`
   - `kpi_summary.csv`
   - `data_quality_summary.csv`
   - PNG charts for the README/portfolio

## Cleaning approach
- Trim column names and standardize types.
- Parse invoice dates.
- Identify cancellation invoices (invoice number starts with `C`).
- Create a revenue field: `Quantity * UnitPrice`.
- For the main sales analysis, exclude cancellation invoices and rows with non-positive quantity or unit price.
- Keep missing customer IDs in transaction-level sales analysis; exclude them only from customer-level metrics.
- Report duplicate and missing-value counts rather than silently hiding data-quality issues.

The script prints the actual row counts and metrics from the downloaded file. **Use those generated results—not guessed numbers—in your resume.**

## Tableau dashboard
1. Run the Python script first.
2. In Tableau, connect to `outputs/cleaned_sales.csv`.
3. Create KPI cards for Total Revenue, Orders, Units Sold, Average Order Value, and Unique Customers.
4. Add:
   - Monthly revenue line chart
   - Top 10 countries by revenue bar chart
   - Top 10 products by revenue bar chart
   - Revenue by country map or bar chart
   - Filters for invoice date, country, and product
5. Save as `tableau/online_retail_sales_dashboard.twbx` and add a screenshot to `images/` before publishing.

## Suggested resume bullet (fill in verified numbers after running)
**Online Retail Sales Analysis | Python, Pandas, NumPy, Tableau**
- Cleaned and analyzed **[verified row count]** public retail transaction records using Pandas/NumPy; assessed duplicates, missing customer IDs, cancellations, and invalid quantities/prices.
- Built a Tableau dashboard tracking **[number] KPIs** and visualizing monthly revenue, top products, and country-level performance.

## Repository structure
```text
online-retail-sales-analytics/
├── data/raw/                 # Download dataset here; do not commit raw file
├── outputs/                  # Generated analysis outputs
├── src/analyze_retail.py
├── sql/analysis_queries.sql
├── tableau/README.md
├── images/
├── requirements.txt
├── .gitignore
└── README.md
```
