Download the official UCI Online Retail.xlsx file and place it in this folder. The raw dataset is intentionally not included in this ZIP.
