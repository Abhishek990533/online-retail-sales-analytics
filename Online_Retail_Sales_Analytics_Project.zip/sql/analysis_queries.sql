-- These queries assume the cleaned_sales.csv has been imported into MySQL
-- as a table named cleaned_sales. Adjust column names/types to your import setup.

-- 1. Total revenue, orders, units sold, and average order value
SELECT
    ROUND(SUM(Revenue), 2) AS total_revenue_gbp,
    COUNT(DISTINCT InvoiceNo) AS unique_orders,
    SUM(Quantity) AS units_sold,
    ROUND(SUM(Revenue) / NULLIF(COUNT(DISTINCT InvoiceNo), 0), 2) AS average_order_value_gbp
FROM cleaned_sales;

-- 2. Monthly revenue trend
SELECT
    DATE_FORMAT(InvoiceDate, '%Y-%m') AS sales_month,
    ROUND(SUM(Revenue), 2) AS revenue_gbp,
    COUNT(DISTINCT InvoiceNo) AS orders
FROM cleaned_sales
GROUP BY DATE_FORMAT(InvoiceDate, '%Y-%m')
ORDER BY sales_month;

-- 3. Top 10 countries by revenue
SELECT
    Country,
    ROUND(SUM(Revenue), 2) AS revenue_gbp,
    COUNT(DISTINCT InvoiceNo) AS orders
FROM cleaned_sales
GROUP BY Country
ORDER BY revenue_gbp DESC
LIMIT 10;

-- 4. Top 10 products by revenue
SELECT
    StockCode,
    Description,
    ROUND(SUM(Revenue), 2) AS revenue_gbp,
    SUM(Quantity) AS units_sold
FROM cleaned_sales
GROUP BY StockCode, Description
ORDER BY revenue_gbp DESC
LIMIT 10;

-- 5. Customer-level spend (only customers with an ID)
SELECT
    CustomerID,
    ROUND(SUM(Revenue), 2) AS customer_revenue_gbp,
    COUNT(DISTINCT InvoiceNo) AS orders
FROM cleaned_sales
WHERE CustomerID IS NOT NULL
GROUP BY CustomerID
ORDER BY customer_revenue_gbp DESC
LIMIT 20;
