from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "raw" / "Online Retail.xlsx"
OUT = ROOT / "outputs"
OUT.mkdir(parents=True, exist_ok=True)

def main():
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Dataset not found at: {DATA_PATH}\n"
            "Download Online Retail.xlsx from https://archive.ics.uci.edu/dataset/352/online-retail "
            "and place it in data/raw/."
        )

    df = pd.read_excel(DATA_PATH)
    df.columns = [str(c).strip() for c in df.columns]

    required = {"InvoiceNo", "StockCode", "Description", "Quantity",
                "InvoiceDate", "UnitPrice", "CustomerID", "Country"}
    missing_cols = required - set(df.columns)
    if missing_cols:
        raise ValueError(f"Dataset is missing expected columns: {sorted(missing_cols)}")

    raw_rows = len(df)
    duplicate_rows = int(df.duplicated().sum())
    missing_customer_ids = int(df["CustomerID"].isna().sum())
    missing_descriptions = int(df["Description"].isna().sum())
    cancellation_mask = df["InvoiceNo"].astype(str).str.upper().str.startswith("C")
    cancellation_rows = int(cancellation_mask.sum())
    nonpositive_quantity_rows = int((df["Quantity"] <= 0).sum())
    nonpositive_price_rows = int((df["UnitPrice"] <= 0).sum())

    df["InvoiceDate"] = pd.to_datetime(df["InvoiceDate"], errors="coerce")
    df["Quantity"] = pd.to_numeric(df["Quantity"], errors="coerce")
    df["UnitPrice"] = pd.to_numeric(df["UnitPrice"], errors="coerce")
    df["Revenue"] = df["Quantity"] * df["UnitPrice"]

    # Drop exact duplicate rows for the analysis, then exclude cancellations and invalid sales lines.
    cleaned = df.drop_duplicates().copy()
    sales = cleaned[
        ~cleaned["InvoiceNo"].astype(str).str.upper().str.startswith("C")
        & cleaned["Quantity"].gt(0)
        & cleaned["UnitPrice"].gt(0)
        & cleaned["InvoiceDate"].notna()
    ].copy()
    sales["InvoiceDate"] = pd.to_datetime(sales["InvoiceDate"])
    sales["Month"] = sales["InvoiceDate"].dt.to_period("M").astype(str)

    monthly = sales.groupby("Month", as_index=False).agg(
        Revenue=("Revenue", "sum"),
        Orders=("InvoiceNo", "nunique"),
        Units_Sold=("Quantity", "sum")
    ).sort_values("Month")
    country = sales.groupby("Country", as_index=False).agg(
        Revenue=("Revenue", "sum"),
        Orders=("InvoiceNo", "nunique"),
        Units_Sold=("Quantity", "sum")
    ).sort_values("Revenue", ascending=False)
    product = sales.groupby(["StockCode", "Description"], dropna=False, as_index=False).agg(
        Revenue=("Revenue", "sum"),
        Units_Sold=("Quantity", "sum"),
        Orders=("InvoiceNo", "nunique")
    ).sort_values("Revenue", ascending=False)

    customer_sales = sales.dropna(subset=["CustomerID"])
    total_revenue = float(sales["Revenue"].sum())
    orders = int(sales["InvoiceNo"].nunique())
    units_sold = float(sales["Quantity"].sum())
    customers = int(customer_sales["CustomerID"].nunique())
    avg_order_value = total_revenue / orders if orders else np.nan

    kpis = pd.DataFrame([
        ("Total revenue (£)", total_revenue),
        ("Unique orders", orders),
        ("Units sold", units_sold),
        ("Average order value (£)", avg_order_value),
        ("Unique customers with ID", customers),
        ("Analysis transaction rows", len(sales)),
    ], columns=["KPI", "Value"])

    quality = pd.DataFrame([
        ("Raw rows", raw_rows),
        ("Exact duplicate rows", duplicate_rows),
        ("Rows with missing CustomerID", missing_customer_ids),
        ("Rows with missing Description", missing_descriptions),
        ("Cancellation invoice rows (invoice starts with C)", cancellation_rows),
        ("Rows with non-positive quantity", nonpositive_quantity_rows),
        ("Rows with non-positive unit price", nonpositive_price_rows),
        ("Rows retained for main sales analysis", len(sales)),
    ], columns=["Check", "Count"])

    sales.to_csv(OUT / "cleaned_sales.csv", index=False)
    monthly.to_csv(OUT / "monthly_revenue.csv", index=False)
    country.to_csv(OUT / "country_revenue.csv", index=False)
    product.to_csv(OUT / "product_revenue.csv", index=False)
    kpis.to_csv(OUT / "kpi_summary.csv", index=False)
    quality.to_csv(OUT / "data_quality_summary.csv", index=False)

    plt.figure(figsize=(10, 5))
    plt.plot(monthly["Month"], monthly["Revenue"], marker="o")
    plt.title("Monthly Revenue")
    plt.xlabel("Month")
    plt.ylabel("Revenue (£)")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.savefig(OUT / "monthly_revenue.png", dpi=160)
    plt.close()

    top_countries = country.head(10).sort_values("Revenue")
    plt.figure(figsize=(9, 5))
    plt.barh(top_countries["Country"], top_countries["Revenue"])
    plt.title("Top 10 Countries by Revenue")
    plt.xlabel("Revenue (£)")
    plt.tight_layout()
    plt.savefig(OUT / "top_countries_revenue.png", dpi=160)
    plt.close()

    top_products = product.dropna(subset=["Description"]).head(10).sort_values("Revenue")
    plt.figure(figsize=(10, 6))
    plt.barh(top_products["Description"].astype(str), top_products["Revenue"])
    plt.title("Top 10 Products by Revenue")
    plt.xlabel("Revenue (£)")
    plt.tight_layout()
    plt.savefig(OUT / "top_products_revenue.png", dpi=160)
    plt.close()

    print("\n=== KPI SUMMARY ===")
    print(kpis.to_string(index=False))
    print("\n=== DATA QUALITY ===")
    print(quality.to_string(index=False))
    print(f"\nOutputs saved to: {OUT}")

if __name__ == "__main__":
    main()
